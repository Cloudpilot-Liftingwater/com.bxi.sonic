#!/usr/bin/env python3
"""Streamed readback of all three JPEGs, raw signals and source-time alignment."""
import argparse
import json
from pathlib import Path
import sys
import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent/'collector'))
from real_robot_collection.wrist_diagnostic import SCHEMA, WRISTS, validate_raw_row
from real_robot_collection.contracts import validate_motion_token, sonic_projected_gravity
from real_robot_collection.gripper_history import blocked_by_intervals
from real_robot_collection.gripper_identity import validate_identities
from session_protocol import capture_segment, validate_pauses


def vector(value, size):
    arr = np.asarray(value, dtype=float)
    if arr.shape != (size,) or not np.isfinite(arr).all():
        raise ValueError(f'invalid {size}-dimensional vector')
    return arr


def verify(episode, *, allow_incomplete=False):
    episode = Path(episode).resolve(strict=True)
    meta = json.loads((episode/'meta.json').read_text())
    if meta.get('schema_version') != SCHEMA or meta.get('training_export_allowed') is not False:
        raise ValueError('not a three-RGB DM/BXI v2 diagnostic source episode')
    expected_grippers = validate_identities(meta.get('gripper_identity_contract'))
    if validate_identities(meta.get('metadata', {}).get('gripper_identities')) != expected_grippers:
        raise ValueError('gripper identity metadata mismatch')
    complete = meta.get('termination', {}).get('success') is True
    discarded = meta.get('discarded') is True
    if discarded and (complete or meta.get('excluded_from_training') is not True
                      or meta.get('termination', {}).get('writer_errors')):
        raise ValueError('invalid discard metadata or writer failure')
    if not complete and not (allow_incomplete and meta.get('incomplete') is True):
        raise ValueError('episode was not finalized successfully')
    if meta.get('metadata', {}).get('physical_ports') != {'left':7, 'right':1}:
        raise ValueError('wrong physical camera roles')
    ingest = meta.get('synchronization', {}).get('gripper_ingest', {})
    pauses = meta.get('synchronization', {}).get('pose_pauses', [])
    validate_pauses(pauses, float('inf'))
    segments = []
    intervals = ingest.get('invalid_intervals', [])
    for barrier in intervals:
        if (not np.isfinite(barrier['start_unix']) or not np.isfinite(barrier['recover_after_unix'])
                or barrier['start_unix'] > barrier['recover_after_unix']):
            raise ValueError('invalid gripper interval metadata')
    stamps, deltas, ages = [], [], []
    last_sequence = {n:-1 for n in WRISTS}
    last_camera_stamp = {n:0. for n in WRISTS}
    last_inference, count, previews = -1, 0, {}
    seen_paths = set()
    with (episode/'frames.jsonl').open() as stream:
        for line in stream:
            row = json.loads(line)
            if row['idx'] != count or row.get('diagnostic_only') is not True:
                raise ValueError('bad row index/diagnostic flag')
            if row.get('dataset.observation.state') is not None or row.get('dataset.action.wbc') is not None:
                raise ValueError('raw motor coordinates cannot masquerade as training coordinates')
            aux, source = row['auxiliary'], row['source_timestamps_unix']
            anchor = float(aux['anchor_stamp_unix'])
            if not np.isfinite(anchor) or anchor <= 0 or stamps and anchor <= stamps[-1]:
                raise ValueError('non-increasing/invalid source anchor')
            if not np.isclose(row['t_episode'], anchor-(stamps[0] if stamps else anchor), atol=1e-7, rtol=0):
                raise ValueError('episode timing is not real source timing')
            segment = capture_segment(anchor, pauses)
            if segment is None or aux.get('capture_segment', 0) != segment:
                raise ValueError('row inside pause or wrong segment')
            if any(capture_segment(float(stamp), pauses) != segment for stamp in source.values()):
                raise ValueError('source sample crosses pause boundary')
            if 'smpl_ref' in aux.get('received_monotonic', {}):
                if capture_segment(aux['received_monotonic']['smpl_ref']+aux['clock_offset_s'], pauses) != segment:
                    raise ValueError('SMPL packet crosses pause boundary')
            segments.append(segment)
            stamps.append(anchor)
            validate_raw_row(row['gripper'], expected_grippers)
            validate_motion_token(row['action.motion_token'])
            inf = row['sonic.inference']
            if inf['sequence'] <= last_inference or inf.get('policy_status') != 'live_reference':
                raise ValueError('reused/non-live inference')
            last_inference = inf['sequence']
            if inf['model_sha256'] != meta['metadata']['motion_token']['sha256']:
                raise ValueError('motion token model mismatch')
            target, action = vector(inf['target_position'],31), vector(row['action'],31)
            if not np.allclose(target[:29], action[:29], atol=1e-5, rtol=0):
                raise ValueError('token and final body action do not match')
            state = vector(row['observation.state'],31)
            if not np.asarray(row['observation.joint_present'], bool)[:29].all():
                raise ValueError('missing body joint feedback')
            imu = row['observation.imu']
            q = vector(imu['orientation_wxyz'],4)
            vector(imu['angular_velocity'],3)
            vector(imu['linear_acceleration'],3)
            gravity = vector(row['observation.projected_gravity'],3)
            if not np.allclose(gravity, sonic_projected_gravity(q,state[:29]), atol=1e-5, rtol=0):
                raise ValueError('projected gravity does not match saved IMU/body')
            if set(row['observation.images']) != set(WRISTS):
                raise ValueError('missing/extra RGB camera')
            for key in ('actuator_state','actuator_command','imu','sonic_inference','gripper_state','gripper_command'):
                if not np.isfinite(source[key]) or abs(source[key]-anchor) > .030001:
                    raise ValueError('source alignment exceeds 30ms: '+key)
            raw = row['gripper']['native_raw_sample']
            if aux.get('gripper_ingest_method') == 'source_history_v2':
                if ingest.get('method') != 'source_history_v2' or 'invalid_intervals' not in ingest:
                    raise ValueError('missing gripper source-history audit')
                latency = aux['received_monotonic']['gripper']-float(raw['monotonic'])
                if (not np.isfinite(latency) or not 0 <= latency <= .75
                        or not np.isclose(aux['gripper_publication_to_callback_s'],latency,atol=1e-7,rtol=0)
                        or abs(source['gripper_state']-float(raw['monotonic'])-aux['clock_offset_s']) > .02):
                    raise ValueError('invalid gripper transport/clock audit')
            if blocked_by_intervals(source['gripper_state'], anchor, intervals):
                raise ValueError('row crosses invalid gripper source interval')
            for item in raw['samples']:
                for suffix, mono in (('feedback',item['feedback_monotonic']),('command',item['command']['sent_monotonic'])):
                    key = item['side']+'_gripper_'+suffix
                    expected = source['gripper_state']+(float(mono)-float(raw['monotonic']))
                    if not np.isfinite(source[key]) or abs(source[key]-anchor) > .050001 or abs(source[key]-expected)>1e-6:
                        raise ValueError('invalid gripper feedback/command time: '+key)
            pico, smpl = row['pico.raw'], row['pico.smpl_ref']
            if int(np.asarray(pico['frame_index']).reshape(-1)[-1]) != int(np.asarray(smpl['frame_index']).reshape(-1)[-1]):
                raise ValueError('PICO/SMPL frame identity mismatch')
            pico_stamp = float(np.asarray(pico['timestamp_realtime']).reshape(-1)[-1])
            if not 0 <= anchor-pico_stamp <= .200001 or source['pico'] != pico_stamp or source['smpl_ref'] != pico_stamp:
                raise ValueError('PICO source stamp/join mismatch')
            for name in WRISTS:
                source_stamp = float(source[name])
                delta = source_stamp-anchor
                if not np.isfinite(delta) or abs(delta) > .025001 or source_stamp <= last_camera_stamp[name]:
                    raise ValueError('invalid/reused camera source stamp: '+name)
                last_camera_stamp[name] = source_stamp
                deltas.append(abs(delta))
                sequence = aux['selected_camera_sequences'][name]
                if sequence <= last_sequence[name]:
                    raise ValueError('reused camera sequence: '+name)
                last_sequence[name] = sequence
                p = (episode/row['observation.images'][name]).resolve()
                if not p.is_relative_to(episode) or p in seen_paths:
                    raise ValueError('outside/reused image path')
                seen_paths.add(p)
                image = cv2.imread(str(p))
                camera = meta['camera_contract']['mounts'][name]
                if image is None or image.shape != (camera['height'],camera['width'],3):
                    raise ValueError('JPEG decode/size failed: '+str(p))
                age = aux['received_monotonic'][name]+aux['clock_offset_s']-source_stamp
                if not np.isfinite(age) or age < -.02:
                    raise ValueError('invalid source/receipt clock relation')
                ages.append(age)
                if count in (0,meta['num_frames']//2,meta['num_frames']-1):
                    previews[f'{name}_{count}'] = str(p)
            count += 1
    if count < (100 if complete else 0 if discarded else 1) or count != meta['num_frames']:
        raise ValueError('too few/mismatched saved rows')
    if discarded and count == 0:
        return dict(episode=str(episode), saved_rows=0, decoded_images=0,
                    readback='METADATA_ONLY', discarded=True, excluded_from_training=True,
                    episode_complete=False, timing_review='NOT_APPLICABLE',
                    training_export_allowed=False)
    gaps = np.diff(stamps)
    duration = stamps[-1]-stamps[0]
    rate = (count-1)/duration if duration > 0 else 0.
    max_gap = float(max(gaps)) if len(gaps) else None
    if not np.isclose(meta['duration_s'],duration,atol=1e-6,rtol=0):
        raise ValueError('metadata duration differs from source timestamps')
    sync = meta.get('synchronization', {})
    same_segment = np.diff(segments) == 0
    active_gaps = gaps[same_segment]
    active_rate = len(active_gaps)/sum(active_gaps) if len(active_gaps) else 0.
    active_max_gap = float(max(active_gaps)) if len(active_gaps) else None
    timing_ok = (complete and 25 <= active_rate <= 32 and active_max_gap is not None
                 and active_max_gap <= .2 and not sync.get('clock_jump', True))
    # Full invalid-interval audit stays in meta.json; keep terminal output compact.
    sync_display = dict(sync)
    if 'gripper_ingest' in sync:
        sync_display['gripper_ingest'] = {k:v for k,v in sync['gripper_ingest'].items()
                                         if k != 'invalid_intervals'}
    return dict(episode=str(episode), saved_rows=count, decoded_images=len(seen_paths),
        actual_row_rate_hz=rate, source_duration_s=duration, maximum_row_gap_s=max_gap,
        uninterrupted_row_rate_hz=active_rate, maximum_uninterrupted_gap_s=active_max_gap,
        recorded_segments=len(set(segments)), pause_count=len(pauses),
        segment_boundaries=[i+1 for i, same in enumerate(same_segment) if not same],
        maximum_camera_to_anchor_delta_ms=1000*max(deltas),
        median_camera_header_to_receipt_ms=1000*float(np.median(ages)),
        synchronization=sync_display, physical_ports={'left':7,'right':1},
        readback='PASS', episode_complete=complete, gripper_identities=expected_grippers,
        discarded=discarded, excluded_from_training=discarded or not complete,
        timing_review=('PASS' if timing_ok else 'REVIEW') if complete else 'INCOMPLETE',
        training_export_allowed=False, preview_files=previews)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('episode', type=Path)
    parser.add_argument('--allow-incomplete',action='store_true',help='Integrity audit only; never marks a partial trial complete.')
    args = parser.parse_args()
    try:
        result = verify(args.episode,allow_incomplete=args.allow_incomplete)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        raise SystemExit(0 if result['timing_review'] == 'PASS' else 2)
    except Exception as exc:
        print('FAIL: '+str(exc), file=sys.stderr)
        raise SystemExit(1)
