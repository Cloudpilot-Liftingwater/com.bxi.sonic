#!/usr/bin/env bash
set -e
PICO_COLLECTION_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
cd -- "$PICO_COLLECTION_ROOT"
sha256sum --quiet -c SHA256SUMS
source "$PICO_COLLECTION_ROOT/environment.sh"
exec /usr/bin/python3 -B -u "$PICO_COLLECTION_ROOT/button_supervisor.py" "$@"
