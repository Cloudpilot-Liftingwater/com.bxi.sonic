"""Pure buffered source-clock matching; receipt time is only diagnostic/deadline data."""
import math
import numpy as np
from .gripper_history import blocked_by_intervals

RGB = ('head_rgb', 'left_wrist_rgb', 'right_wrist_rgb')


def stamp_valid(stamp):
    return math.isfinite(stamp) and stamp > 0


def nearest(samples, stamp, tolerance, *, causal=False, after_sequence=-1):
    candidates = [s for s in samples if stamp_valid(s.stamp_unix)
                  and abs(s.stamp_unix-stamp) <= tolerance + 1e-7
                  and (not causal or s.stamp_unix <= stamp + 1e-7)
                  and getattr(s, 'sequence', after_sequence+1) > after_sequence]
    return min(candidates, key=lambda s: (abs(s.stamp_unix-stamp), s.stamp_unix), default=None)


def scalar(snapshot, key):
    values = np.asarray(snapshot.fields[key]).reshape(-1)
    value = float(values[-1])
    if not math.isfinite(value):
        raise ValueError('invalid packed stream scalar '+key)
    return value


def packed_pair(picos, smpls, anchor, tolerance=.2):
    # SMPL has no independent wall-clock stamp. Bind it to the exact PICO
    # frame_index, retain both raw payloads, and declare that derivation.
    for pico in sorted(picos, key=lambda p: p.received_monotonic, reverse=True):
        try:
            stamp = scalar(pico, 'timestamp_realtime')
            if not 0 <= anchor-stamp <= tolerance or not pico.calibrated or pico.stream_mode != 1:
                continue
            matches = [s for s in smpls if s.frame_index == pico.frame_index
                       and abs(s.received_monotonic-pico.received_monotonic) <= tolerance]
            if matches:
                return pico, min(matches, key=lambda s: abs(s.received_monotonic-pico.received_monotonic)), stamp
        except (KeyError, ValueError, IndexError, TypeError):
            continue
    return None, None, None


def choose_bundle(anchor, histories, images, last_camera, last_inference, picos, smpls,
                  camera_tolerance=.025, robot_tolerance=.03):
    stamp = anchor.stamp_unix
    bundle, missing = {}, []
    for key in ('state', 'command', 'imu', 'gripper'):
        bundle[key] = nearest(histories[key], stamp, robot_tolerance, causal=True)
        if bundle[key] is None:
            missing.append(key)
    bundle['rgb'] = {'head_rgb': anchor}
    for name in RGB[1:]:
        sample = nearest(images[name], stamp, camera_tolerance, after_sequence=last_camera[name])
        bundle['rgb'][name] = sample
        if sample is None:
            missing.append(name)
    command = bundle['command']
    inference = None
    if command is not None:
        candidates = [s for s in histories['inference']
                      if s.inference_sequence > last_inference
                      and abs(s.stamp_unix-command.stamp_unix) <= .03
                      and abs(s.stamp_unix-stamp) <= robot_tolerance
                      and s.policy_status == 'live_reference'
                      and np.allclose(s.target_position[:29], command.position[:29], rtol=0, atol=1e-5)]
        inference = min(candidates, key=lambda s: abs(s.stamp_unix-command.stamp_unix), default=None)
    bundle['inference'] = inference
    if inference is None:
        missing.append('matched_sonic_inference')
    if command is not None and command.diagnostic_action_history is None:
        missing.append('action_history')
    gripper = bundle['gripper']
    if blocked_by_intervals(gripper.stamp_unix if gripper is not None else None,
                            stamp, histories.get('gripper_invalid_intervals', ())):
        missing.append('gripper_invalid_source_interval')
    if gripper is not None:
        raw = gripper.raw
        for item in raw['samples']:
            for mono in (item['feedback_monotonic'], item['command']['sent_monotonic']):
                source = gripper.stamp_unix + (float(mono)-float(raw['monotonic']))
                if not math.isfinite(source) or abs(source-stamp) > .05:
                    missing.append('gripper_feedback_or_command_source_age')
    pico, smpl, pico_stamp = packed_pair(picos, smpls, stamp)
    bundle.update(pico=pico, smpl=smpl, pico_stamp=pico_stamp)
    if pico is None:
        missing.append('pico_smpl_source_frame_pair')
    return bundle, missing


class AnchorBuffer:
    def __init__(self, wait_s=.25, max_age_s=.75):
        if not .15 <= wait_s <= .5 or not wait_s < max_age_s <= 2:
            raise ValueError('invalid bounded buffering window')
        self.wait_s, self.max_age_s = wait_s, max_age_s
        self.reset(0)

    def reset(self, start_unix):
        self.start_unix = start_unix
        self.last_sequence, self.last_stamp = -1, 0.

    def ready(self, frames, now):
        candidates = [f for f in frames if f.sequence > self.last_sequence
                      and f.stamp_unix >= self.start_unix and now-f.stamp_unix >= self.wait_s]
        return min(candidates, key=lambda f: f.sequence, default=None)

    def consume(self, anchor, now):
        reason = None
        if not stamp_valid(anchor.stamp_unix) or anchor.stamp_unix <= self.last_stamp:
            reason = 'non_increasing_source_clock'
        elif now-anchor.stamp_unix > self.max_age_s:
            reason = 'source_frame_too_late'
        self.last_sequence = anchor.sequence
        self.last_stamp = max(self.last_stamp, anchor.stamp_unix)
        return reason
