"""Confirmed USB topology. No writes to deployed controller/camera configuration."""
from pathlib import Path
import os
import re
import yaml
from real_robot_collection.gripper_identity import identities

ROOT = Path(__file__).resolve().parent
PORTS = {'left':7, 'right':1}
FIXED_CAMERA_SHA256 = 'f9fd906092b666bf017898928c19d1f6e3240dad1a5ffbbe54138e63fdeb11ee'


def add_gripper_arguments(parser):
    parser.add_argument('--left', choices=('dm', 'bxi'), default='dm')
    parser.add_argument('--right', choices=('dm', 'bxi'), default='dm')
    parser.add_argument('--left-id', type=int)
    parser.add_argument('--right-id', type=int)
    parser.add_argument('--left-bus', type=int, choices=(5, 6), default=5)
    parser.add_argument('--right-bus', type=int, choices=(5, 6), default=6)


def configuration(left='dm', right='dm', left_id=None, right_id=None, *, left_bus=5, right_bus=6):
    expected = identities(left, right, left_id, right_id, left_bus=left_bus, right_bus=right_bus)
    cfg = yaml.safe_load((ROOT/'collector/config/real_collection.yaml').read_text())
    cfg['dataset'].update(embodiment='elf3_three_rgb_gripper_diagnostic',
        output_root='/home/bxi/three_rgb_gripper_data', fps=30, min_episode_frames=100,
        jpeg_quality=90, queue_capacity=16, default_task_id='three_rgb_gripper_trial',
        tasks=[dict(id='three_rgb_gripper_trial', instruction=f'Diagnostic trial: three RGB cameras, left {left} / right {right} PICO teleoperation.')])
    cfg['sequence']['history_size'] = 2048
    cfg['gripper'] = dict(enabled=True, sample_topic='/sonic/gripper_sample',
        state_joint_names=['left_gripper','right_gripper'], command_joint_names=['left_gripper','right_gripper'],
        mapping={'verified':False}, expected_identities=expected)
    cfg['requirements'].update(formal_collection=False, diagnostic_three_rgb_gripper=True,
                               require_pico_calibrated=True)
    cfg['robot']['odom_topic'] = ''
    cfg['robot']['touch_topic'] = ''
    cfg['cameras']['history_size'] = 24
    cfg['cameras']['max_delta_ms'] = 25.
    cfg['cameras']['head_depth'] = dict(enabled=False)
    cfg['cameras']['head_rgb'].update(enabled=True, width=1920, height=1080, fps=30,
        topic='/hardware/head_depth_camera/color/image_raw', message_type='raw',
        serial='existing_head_driver_serial_not_probed', calibration_file='not_verified')
    for side, port in PORTS.items():
        cfg['cameras'][side+'_wrist_rgb'].update(enabled=True, width=640, height=480, fps=30,
            topic=f'/bxi_trial/{side}/image_raw', camera_info_topic=f'/bxi_trial/{side}/camera_info',
            message_type='raw', serial=f'/dev/v4l/by-path/pci-0000:00:14.0-usb-0:{port}:1.0-video-index0',
            frame_id=f'{side}_wrist_camera_optical_frame', calibration_file='not_verified')
    cfg['metadata'] = dict(robot_serial='elf3-test-01', operator_id='diagnostic_operator',
        site='three_rgb_gripper_trial', camera_calibration_status='not_verified',
        gripper_identities=expected,
        collector_release=ROOT.name,
        camera_left_right_verified=True, physical_ports=dict(PORTS),
        camera_role_evidence='User confirmed USB7 left / USB1 right by occluded-lens preview, 2026-09-29',
        notes='Raw diagnostic source only. DM/BXI identity is explicit; no verified motor-to-checkpoint mapping; training export prohibited.')
    return cfg


def resolve_devices(cfg):
    resolved = {}
    for side in PORTS:
        path = Path(cfg['cameras'][side+'_wrist_rgb']['serial']).resolve(strict=True)
        if not re.fullmatch(r'/dev/video[0-9]+', str(path)) or not path.is_char_device():
            raise RuntimeError('not a canonical V4L2 camera: '+str(path))
        if not os.access(path, os.R_OK | os.W_OK):
            raise RuntimeError('camera access denied: '+str(path))
        resolved[side] = str(path)
    if len(set(resolved.values())) != 2:
        raise RuntimeError('both camera ports resolve to the same device')
    return resolved


def camera_command(side, device):
    if side not in PORTS or not re.fullmatch(r'/dev/video[0-9]+', device):
        raise ValueError('requires left/right and resolved /dev/videoN')
    return ['ros2','run','usb_cam','usb_cam_node_exe','--ros-args','--params-file',
        f'/home/bxi/bxi_vla_ws/real_robot_collection/config/{side}_wrist_usb.yaml',
        '-r',f'__node:={side}_bxi_trial_camera','-r',f'__ns:=/bxi_trial/{side}',
        '-p',f'video_device:={device}','-p','image_width:=640','-p','image_height:=480',
        '-p','framerate:=30.0','-p',f'camera_name:={side}_wrist_camera',
        '-p',f'frame_id:={side}_wrist_camera_optical_frame']
