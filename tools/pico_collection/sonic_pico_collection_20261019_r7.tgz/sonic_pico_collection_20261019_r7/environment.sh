#!/usr/bin/env bash
test "$(hostname -s)" = elf3-test-01 || return 1
source /home/bxi/sonic_gripper_fastfollow_20260917/environment.sh || return 1
WRIST_COLLECTION_ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
export BXI_CONTROLLER_ROOT=/home/bxi/bxi_vla_ws/bxi_rl_controller_ros2_example
export BXI_INSTALL_SETUP="$BXI_CONTROLLER_ROOT/install/setup.bash"
export BXI_LOCAL_ROS_PREFIX=/home/bxi/bxi_vla_ws/real_robot_collection/.ros_local_root/opt/ros/humble
export BXI_ROS_DOMAIN_ID=31 COLLECTION_PROFILE=real PYTHONDONTWRITEBYTECODE=1
source "$WRIST_COLLECTION_ROOT/collector/scripts/common.sh"
collection_configure_local_ros_prefix
export PYTHONPATH="$WRIST_COLLECTION_ROOT/collector:${PYTHONPATH:-}"
