#!/usr/bin/env python3
"""Only own camera/collector processes; never launch controller, CAN or head camera."""
import fcntl
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import yaml

from configure import configuration, resolve_devices, camera_command, FIXED_CAMERA_SHA256, add_gripper_arguments
from check_config import validate_config
from trial_lifecycle import wait_for_trial, audit_after_stop, child_failure


def output(args):
    return subprocess.run(args, text=True, capture_output=True, timeout=10)


def stop(child):
    if child.poll() is not None:
        return
    try:
        os.killpg(child.pid, signal.SIGINT)
    except ProcessLookupError:
        return
    # Never kill a collector that may be flushing saved frames.
    while child.poll() is None:
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            print(f'Waiting for owned child {child.pid} to flush/exit; no forced kill.', flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--session-dir', type=Path)
    add_gripper_arguments(parser)
    args = parser.parse_args()
    session = args.session_dir
    if session is not None:
        if (not session.is_dir() or session.is_symlink() or session.resolve() != session
                or session.parent != Path('/home/bxi/pico_collection_runs')
                or not session.name.startswith('session_')
                or session.stat().st_uid != os.getuid() or session.stat().st_mode & 0o077):
            raise RuntimeError('requires a private owned /home/bxi/pico_collection_runs/session_* directory')
        from session_protocol import read_intent
        read_intent(session)
    if socket.gethostname().split('.')[0] != 'elf3-test-01' or os.environ.get('ROS_DOMAIN_ID') != '31':
        raise RuntimeError('requires elf3-test-01 and Domain 31')
    lock = open('/home/bxi/.three_rgb_bxi_trial.lock','a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    # Keep the historic lock/namespace shared across all releases. Also exclude
    # an idle PICO listener: Y+A must never launch two independent collectors.
    listener_lock = None
    if session is None:
        runs = Path('/home/bxi/pico_collection_runs')
        runs.mkdir(exist_ok=True)
        listener_lock = (runs/'listener.lock').open('a')
        try:
            fcntl.flock(listener_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('PICO collection listener already active; stop only that listener normally before this trial')
    cfg = configuration(args.left, args.right, args.left_id, args.right_id,
                        left_bus=args.left_bus, right_bus=args.right_bus)
    if session is not None:
        cfg['dataset']['output_root'] = '/home/bxi/pico_collection_data'
    validate_config(cfg, formal=False, allow_placeholders=False)
    library = Path('/home/bxi/bxi_vla_ws/real_robot_collection/.ros_local_root/opt/ros/humble/lib/libusb_cam.so')
    if hashlib.sha256(library.read_bytes()).hexdigest() != FIXED_CAMERA_SHA256:
        raise RuntimeError('fixed usb_cam clock library is not installed')
    if output(['pgrep','-af','[r]eal_robot_collection[.](node|source_node)']).returncode == 0:
        raise RuntimeError('another collector is running; no process stopped')
    topics = output(['ros2','topic','list','--no-daemon'])
    if topics.returncode or '/elf3/recording_status' in topics.stdout or '/bxi_trial/' in topics.stdout:
        raise RuntimeError('collector namespace busy or ROS inspection failed')
    devices = resolve_devices(cfg)
    if not shutil.which('fuser'):
        raise RuntimeError('fuser is required to avoid duplicate camera owners')
    for side, device in devices.items():
        busy = output(['fuser',device])
        if busy.returncode != 1 or busy.stderr.strip():
            raise RuntimeError(f'{device} busy or ownership check failed; no process stopped')
        cfg['cameras'][side+'_wrist_rgb']['resolved_video_device'] = device
    if shutil.disk_usage('/home/bxi').free < 3*1024**3:
        raise RuntimeError('need 3 GiB free for this trial')
    root = session or Path(tempfile.mkdtemp(prefix='three_rgb_gripper_run_',dir='/home/bxi'))
    config = root/'trial.yaml'
    with config.open('x') as handle:
        handle.write(yaml.safe_dump(cfg,allow_unicode=True,sort_keys=False))
    data = Path(cfg['dataset']['output_root'])/root.name/'three_rgb_gripper_source'
    episode = data/'episode_0000'
    print(f'RUN_DIR={root}\nDATA_ROOT={data}',flush=True)
    print('COLLECTOR_RELEASE='+Path(__file__).resolve().parent.name,flush=True)
    print('EXPECTED_GRIPPERS='+json.dumps(cfg['gripper']['expected_identities']),flush=True)
    print('Gripper source-history v2: preserve valid history; audit invalid intervals; separate transport latency.',flush=True)
    print('USB7=LEFT, USB1=RIGHT; existing head RGB. DIAGNOSTIC RAW SOURCE, not training export.',flush=True)
    print('PICO session requested: left grip+A saves, left grip+B discards; A+X pauses/resumes the same episode; max 600 active seconds; no fault retry.' if session else
          'Keep existing SONIC/PICO live. When missing=[]: Y+A starts; auto-finish after 30s; Y+B ends early.',flush=True)
    print('No motion commands, head driver launch, services or deployed config changes.',flush=True)
    children, logs, failure = [], [], None
    try:
        if resolve_devices(cfg) != devices:
            raise RuntimeError('USB topology changed; rerun')
        for side, device in devices.items():
            log = (root/f'camera_{side}.log').open('w'); logs.append(log)
            process = subprocess.Popen(camera_command(side,device),stdout=log,
                stderr=subprocess.STDOUT,start_new_session=True)
            children.append(dict(name=side+'_wrist_camera', process=process, log=str(root/f'camera_{side}.log')))
        time.sleep(2)
        failure = child_failure(children)
        if failure is None:
            command = ([sys.executable,'-B','-u',str(Path(__file__).parent/'session_node.py'),
                        '--session-dir',str(session)] if session else
                       [sys.executable,'-B','-u','-m','real_robot_collection.source_node'])
            process = subprocess.Popen(command+['--config',str(config),'--data-id',root.name],start_new_session=True)
            children.append(dict(name='collector',process=process,log='launcher terminal/local log'))
            if session:
                from session_protocol import wait_for_session
                failure = wait_for_session(episode,data,children,session)
            else:
                failure = wait_for_trial(episode,data,children)
    except KeyboardInterrupt:
        failure = dict(reason='operator_or_session_interrupt')
    except Exception as exc:
        failure = dict(reason='launcher_exception', error=str(exc))
    finally:
        if failure:
            print('CAPTURE_STOP='+json.dumps(failure,ensure_ascii=False),flush=True)
        # Signal only owned children. Collector flushes before camera cleanup.
        for child in reversed(children):
            stop(child['process'])
        for log in logs:
            log.close()
    # Recheck final files AFTER shutdown: a camera can die while the collector
    # is already finalizing. That must not suppress its saved-data readback.
    result_file = session/'session_result.json' if session else None
    session_result = json.loads(result_file.read_text()) if result_file and result_file.is_file() else None
    report = audit_after_stop(episode,data,failure,session_result)
    (root/'launcher_status.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report['exit_code']


if __name__ == '__main__':
    signal.signal(signal.SIGTERM, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    signal.signal(signal.SIGHUP, lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as exc:
        print('STOP: '+str(exc),flush=True)
        raise SystemExit(1)
