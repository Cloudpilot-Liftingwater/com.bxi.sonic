# ELF3 PICO 采集 r7（2026-10-19）

**A+X 切出 POSE 暂停采集；切回有效 POSE 后，继续录同一条。**
暂停不会结束 episode，也不创建新目录。motion_token、三路图像、身体和夹爪状态一起暂停写入。
正常操作下，明确保存/弃用才结束这一条；无需左菜单键。

## 安装

这是 r6 的采集器升级，不包含 SONIC 身体、夹爪控制文件。
当前双 BXI 左 CAN6/ID1、右 CAN5/ID1 配置及 DM 解析逻辑保持不变。
同时兼容当前 playout-01 的完整 SMPL chunk，修复旧采集器只接受旧 readiness 字段的问题。

先结束正在录制的任务，等保存/校验完成。操作员正常停止旧采集监听器后运行安装器。
安装器拒绝替换运行中的监听器，不会自动停止服务；安装后只启动空闲采集监听器。
看到 `PICO_COLLECTION_READY: sonic_pico_collection_20261019_r7` 才按本页测试。
未收到安装成功回执前，机器人仍按旧 r6 行为：切出 POSE 会结束当前条。

## 按键与一次测试

| 操作 | 结果 |
|---|---|
| 左握把+A（空闲时） | 开始新条；等 RECORDING、accepted_rows 增长 |
| A+X 切出 POSE | PAUSED；保留同一个 session，排空已到达的暂停前数据后帧数停止增长 |
| A+X 切回已标定 POSE | RECORDING；输入重新有效后继续增长，session 不变 |
| 左握把+A（录制或暂停时） | 保存整条，包括暂停前后所有有效数据 |
| 左握把+B（录制或暂停时） | 弃用整条，保留原文件并排除 |

左握把是中指侧键，不是夹爪扳机。兼容键仍为 Y+A 开始、Y+B 保存。
建议一次录 10 秒 → A+X 暂停 5 秒 → A+X 恢复再录 10 秒 → 保存。
应只新增一个 session 和一个 episode_0000；audit.json 显示 recorded_segments=2、pause_count=1。
相机继续运行以便恢复，但暂停区间的图像和重复推理标签不写入数据行。
独立真机跟踪记录器可持续记录整个过程，与本采集暂停互不影响。

## 时间和边界

同一条里的行号连续，真实源时间戳保留暂停间隔，不压缩或伪造时间。
每行 auxiliary.capture_segment 标记连续片段，meta.json 的 synchronization.pose_pauses 记录暂停区间。
后续构造连续训练窗口时不能跨 capture_segment；两段仍属于同一个任务 episode。
读回校验逐张解码图像，拒绝暂停区间的数据行及跨暂停边界拼接的源样本。
间隔统计分别提供整条时长和片段内帧率，不把主动暂停误报为丢帧。

开始时仍等待输入最多30秒；最大600秒指非主动暂停的录制时段，暂停不计入。
完整网络断流、相机掉线、低磁盘、时钟异常仍会中断并保留数据，不会伪装成 A+X 暂停。
退出 SONIC 状态仍结束当前条；A+X 只切换 PICO 模式，机器人保持在 SONIC。

## 文件

状态：`/home/bxi/pico_collection_runs/status.json`。
会话及校验：`/home/bxi/pico_collection_runs/session_*/`。
数据：`/home/bxi/pico_collection_data/<session>/three_rgb_gripper_source/episode_0000/`。
弃用：`_discarded`；异常：`_interrupted`。已有数据不删除。

输出仍为 elf3_three_rgb_gripper_source/v2 原始诊断数据，training_export_allowed=false；
本次不更改 GR00T 训练坐标映射、相机驱动或夹爪参数。离线验证不代替本版真机测试。
